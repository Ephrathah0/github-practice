// Import necessary modules and components
import { Blog } from "@/data/blog";
import Link from "next/link";

// Define the BlogCard component and pass in the necessary props from the Blog type
export default function BlogCard({ title, content, id }: Blog) {
    return (
        // Outer container for the blog card, styling with CSS classes
        <div className="bg-slate-100 w-3/12	 max-h-[300rem] rounded-md overflow-hidden m-4">
            {/* Display the blog image */}
            
            {/* Container for the blog content */}
            <div className="p-4">
                {/* Display the blog title */}
                <h2 className="font-bold text-xl text-center">{title}</h2>
</div>
<div>
                {/* Display a preview of the blog content */}
                <p>{content.slice(0, 100)}</p>
            </div>

            {/* Link to the full blog post using the blog's ID */}
            <Link href={`/blogs/${id}`} className="bg-white py-2 w-[8rem] text-center block mx-auto rounded-full shadow-sm hover:scale-105">
                Read more
            </Link>

            {/* Container for the author information */}
            
                
                <span className="block ml-auto">
                    {"" /* Placeholder text, originally intended for showing the date */}
                </span>
            </div>
                );
}
