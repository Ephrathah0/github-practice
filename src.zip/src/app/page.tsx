import Image from 'next/ge'
import About from './blogs/page'

export default function Home() {
  return (
    <div>
      <h1 className="text-center text-3xl font-semibold">Blog App</h1>
      <About/>
    </div>
  )
}
