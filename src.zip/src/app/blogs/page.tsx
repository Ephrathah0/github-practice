'use client';
import BlogCard from "@/components/blogCard";
import { Blog, randomId, getBlogs } from "@/data/blog";
import { useEffect, useState } from "react";

const data: Blog = {
    id: randomId(),
    title: "Web dev",
    content: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eaque, atque laudantium! Recusandae neque dolore repudiandae ducimus assumenda obcaecati quo! Maxime esse ipsam tenetur delectus dignissimos distinctio autem asperiores architecto ex?",
        }
export default function About() {
    const [blogs, setBlogs] = useState<Blog[]>([])
    useEffect(() => {
        getBlogs().then(response => setBlogs(response))
        console.log(blogs)
    }, []);

    return (
        <>
            <div>
                
            </div>
            <div className="p-8 px-20 flex flex-wrap justify-between">
                {blogs.map((blog, i) => {
                    return (
                        <>
                            <BlogCard key={i} {...blog} />
                           
                        </>
                    )
                })}
            </div>
        </>
    )
}